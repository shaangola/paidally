require('./bootstrap');
 
/* Import the Main component */
import Main from './components/Main';